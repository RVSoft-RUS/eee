﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Text

Public Class Form1
    Private id As String = "0"         '1011
    Private name1 As String = " "       '3
    Private company As String = " "    '7
    Private contacts As String = " "   '9
    Private about As String = " "      '121
    Private endDate As String = "0"      '167
    Private stream As String = "0"       '255 ' = level
    Private num_lic As String        '254 ' = license number

    Dim t As Long

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        id = code(TextBox1.Text)
        name1 = code(TextBox2.Text)
        company = code(TextBox3.Text)
        contacts = code(TextBox4.Text)
        about = code(TextBox5.Text)
        stream = ComboBox1.SelectedIndex + 1
        Dim date1 As Date
        date1 = DateTimePicker1.Value
        Dim endD As Long = date1.Ticks
        If endD < Now.Ticks Then endD = 0

        Dim N As Long = Now.Ticks
        Dim f As String = Application.StartupPath + "\" + Convert.ToString(N, 16) + ".elc"
        LabelOut.Text = f
        If f.Length > 50 Then
            LabelOut.Text = "..." + f.Remove(0, 50)
        End If


        Dim arr As New Hashtable From {
            {1011, id},
            {3, name1},
            {7, company},
            {9, contacts},
            {121, about},
            {167, endD},
            {255, stream}
        }


        Dim fStream As New FileStream(f, FileMode.Create, FileAccess.Write)
        Dim myBinaryFormatter As New Formatters.Binary.BinaryFormatter
        myBinaryFormatter.Serialize(fStream, arr)
        fStream.Close()

        Dim txt As New StringBuilder
        txt.Append("==========" + Now.ToLongDateString + "==========" + vbCrLf)
        txt.Append("id = " + TextBox1.Text + vbCrLf)
        txt.Append("name = " + TextBox2.Text + vbCrLf)
        txt.Append("company = " + TextBox3.Text + vbCrLf)
        txt.Append("contacts = " + TextBox4.Text + vbCrLf)
        txt.Append("about = " + TextBox5.Text + vbCrLf)
        If endD = 0 Then
            txt.Append("dateEnd = нет" + vbCrLf)
        Else
            txt.Append("dateEnd = " + date1.ToLongDateString + vbCrLf)
        End If
        txt.Append("Примечание = " + TextBox6.Text + vbCrLf)
        txt.Append("Ключ = " + f + vbCrLf)
        txt.Append("version = " + ComboBox1.Text + vbCrLf)

        f = Application.StartupPath + "\отчет.txt"
        File.AppendAllText(f, txt.ToString)
    End Sub

    Function code(s As String) As String
        Dim sb As New StringBuilder
        Dim c() As Char
        Dim cur As Char
        c = s.ToCharArray
        Dim j As Integer = 1
        Dim k As Integer
        For i = 0 To c.Count - 1
            k = AscW(c(i))
            k = k - j
            cur = ChrW(k)
            sb.Append(cur)
            j += 1
            If j = 10 Then j = 1
        Next
        Return sb.ToString
    End Function

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) 
        For Each ctrl As Control In Me.Controls
            Dim str As String = ctrl.Text + ""
            If str = "" Then
                ctrl.Enabled = False
            End If
        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim s As String = InputBox("Date")
        If s <> "12019856" Then
            End
        End If
    End Sub
End Class
