﻿Public Class Form4
    Dim SymId As Integer

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        Form1.Job.JumpToID(SymId)

        Form1.App.PutMessage("Символ - " + Form1.Sym.GetName + vbTab + Form1.Sym.GetTypeName)
        If Form1.OutDiag Then
            Dim s As String = ""
            Dim k As Integer = Form1.Sym.GetAttributeIds(Form1.AttributeIds)
            Form3.AddText("_______________________________________________")
            For j = 1 To k
                Form1.Att.SetId(Form1.AttributeIds(j))
                s = Form1.Att.GetName + ":" + vbTab + Form1.Att.GetValue

                Form3.AddText(s)
            Next
            If s = "" Then Form3.AddText("Нет атрибутов для указанного символа: " + Form1.Sym.GetTypeName)
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim i As Integer
        i = ListBox1.SelectedIndex + 1
        SymId = Form1.SymIds(i)
        Form1.Sym.SetId(SymId)
    End Sub

    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Form1.ViewSymbols = False
    End Sub

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Form1.ViewSymbols = True
    End Sub
End Class