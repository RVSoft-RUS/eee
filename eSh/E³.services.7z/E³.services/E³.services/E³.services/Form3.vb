﻿Imports System.ComponentModel

Public Class Form3
    Public Sub AddText(txt As String)
        TextBox1.Text = TextBox1.Text + vbCrLf + txt
        TextBox1.SelectionStart = TextBox1.TextLength
        TextBox1.ScrollToCaret()
    End Sub


    Private Sub Form3_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.CheckBox1.Checked = False
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.Top = My.Computer.Screen.WorkingArea.Height - Me.Height
        Me.Left = My.Computer.Screen.WorkingArea.Width - Me.Width
    End Sub
End Class