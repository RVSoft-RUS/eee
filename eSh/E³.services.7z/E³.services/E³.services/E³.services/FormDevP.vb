﻿Imports System.ComponentModel

Public Class FormDevP
    Private Sub FormDevP_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form1.Enabled = False
        Form2.Enabled = False
        Form1.App.PutMessage("Изделие - " + Form1.Dev.GetName + vbTab + Form1.Dev.GetComponentName + " взято на редактирование.")
        If Form1.OutDiag Then
            Form3.AddText("***********************************************")
            Form3.AddText("Взято на редактирование: Изделие - " + Form1.Dev.GetName + vbTab + Form1.Dev.GetComponentName)
        End If
        TextBox1.Text = Form1.Dev.GetName
        TextBox2.Text = Form1.Dev.GetComponentName
        'If Form1.OutDiag Then
        '    Dim s As String
        '    Dim k As Integer = Form1.Dev.GetAttributeIds(Form1.AttributeIds)
        '    Form3.AddText("_______________________________________________")
        '    For j = 1 To k
        '        Form1.Att.SetId(Form1.AttributeIds(j))
        '        s = Form1.Att.GetName + ":" + vbTab + Form1.Att.GetValue
        '        Form3.AddText(s)
        '    Next
        'End If
        Button1.Enabled = False
    End Sub

    Private Sub Changed(sender As Object, e As EventArgs) Handles TextBox1.TextChanged, TextBox1.TextChanged
        Button1.Enabled = True
    End Sub

    Private Sub FormDevP_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.Enabled = True
        Form2.Enabled = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Dev.SetName(TextBox1.Text)
        Form1.Dev.SetComponentName(TextBox2.Text, "x")
        Button1.Enabled = False
        If Form1.OutDiag Then
            Form3.AddText("Изменены некоторые атрибуты изделия: " + Form1.Dev.GetName + vbTab + Form1.Dev.GetComponentName)
        End If
    End Sub
End Class