﻿Imports e3
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Runtime.InteropServices.ComTypes
Imports System.Globalization

Public Class Form1
    <Flags()>
    Private Enum FLASH_TYPE As UInteger
        [Stop] = &H0
        Caption = &H1
        Tray = &H2
        All = &H3
        Timer = &H4
        TimerNoForeground = &HC
    End Enum

    <StructLayout(LayoutKind.Sequential)>
    Private Structure FLASHWINFO
        Public cbSize As Integer
        Public hwnd As IntPtr
        Public dwFlags As FLASH_TYPE
        Public uCount As UInteger
        Public dwTimeout As UInteger
    End Structure
    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function FlashWindowEx(<[In]()> ByRef pfwi As FLASHWINFO) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function
    'Выше для моргания окна
    <DllImport("ole32.dll", ExactSpelling:=True, PreserveSig:=False)>
    Private Shared Function GetRunningObjectTable(ByVal reserved As Int32) As IRunningObjectTable
    End Function
    <DllImport("ole32.dll", CharSet:=CharSet.Unicode, ExactSpelling:=True, PreserveSig:=False)>
    Private Shared Function CreateItemMoniker(ByVal lpszDelim As String, ByVal lpszItem As String) As IMoniker
    End Function
    <DllImport("ole32.dll", ExactSpelling:=True, PreserveSig:=False)>
    Private Shared Function CreateBindCtx(ByVal reserved As Integer) As IBindCtx
    End Function
    <ComImport(), Guid("00000001-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)>
    Interface IClassFactory
        Function CreateInstance(ByVal pUnkOuter As IntPtr, ByRef riid As Guid, ByRef ppvObject As IntPtr) As Integer
    End Interface
    <Flags()>
    Enum E3Type
        E3 = 1
        DBE = 2
    End Enum
    Private Function GetRunningE3Objects() As Hashtable
        GetRunningE3Objects = New Hashtable
        Dim bc As IBindCtx = Nothing
        Dim rot As IRunningObjectTable = Nothing
        Dim ret As Integer = 0
        Try
            bc = CreateBindCtx(0)
            rot = GetRunningObjectTable(0)
            Dim displayName As String = ""
            Dim enumMkr As IEnumMoniker = Nothing
            rot.EnumRunning(enumMkr)
            enumMkr.Reset()

            Dim moniker As IMoniker = Nothing
            Dim elts(1) As IMoniker
            Dim cnt As Integer = 0
            Dim tmpSplit() As String
            Dim obj As Object

            Do While enumMkr.Next(1, elts, cnt) = 0
                Try
                    moniker = elts(0)
                    If moniker Is Nothing = False Then
                        moniker.GetDisplayName(bc, Nothing, displayName)
                        tmpSplit = displayName.Split(":")
                        If tmpSplit.Length = 2 Then
                            If E3Type.E3 AndAlso tmpSplit(0).ToUpper(CultureInfo.InvariantCulture) = "!E3APPLICATION" And IsNumeric(tmpSplit(1)) = True Then
                                obj = Nothing
                                rot.GetObject(moniker, obj)
                                GetRunningE3Objects.Add(CInt(tmpSplit(1)), obj)
                            ElseIf E3Type.DBE AndAlso tmpSplit(0).ToUpper(CultureInfo.InvariantCulture) = "!E3DBEAPPLICATIONFACTORY" And IsNumeric(tmpSplit(1)) = True Then
                                Dim factory As Object = Nothing
                                rot.GetObject(moniker, factory)
                                If TypeOf factory Is IClassFactory Then
                                    Dim guidIUnknown As Guid = New Guid("00000000-0000-0000-C000-000000000046")
                                    Dim appObj As Object = Nothing
                                    factory.CreateInstance(IntPtr.Zero, guidIUnknown, appObj)
                                    GetRunningE3Objects.Add(CInt(tmpSplit(1)), Marshal.GetObjectForIUnknown(appObj))
                                End If
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString & vbCrLf & ret.ToString)
        Finally

        End Try
    End Function



    Dim WshShell As Object

    Public App As e3.e3Application 'Приложение E3
    Public Job As e3.e3Job 'Проект E3
    Public JobIds()   'Массив id проектов 

    Public Sheet As e3.e3Sheet 'Лист E3
    Public SheetIds()  'Массив id листов 
    Dim jobName, SheetName As String 'Имя проекта, Имя листа 

    Public Dev As e3.e3Device
    Public DevIds()  'Массив id изделий 
    Public NumOfDevices As Integer ' кол-во изделий

    Public Sym As e3.e3Symbol
    Public SymIds()  'Массив id символов 
    Public NumOfSyms As Integer ' кол-во символов


    Public Att As New e3.e3Attribute ' аттрибут
    Public AttributeIds() 'Массив ID аттрибутов

    Dim Conn As New e3.e3Bundle
    Dim ConnIds()
    Public NumOfConns As Integer ' кол-во соединений

    Public OutDiag As Boolean = False


    Public ViewDevises As Boolean = False
    Public ViewSymbols As Boolean = False

    Function ConnectToE3() As Boolean
        'True = Connect is OK
        'False= Not connect. Exit
        Dim objWMIService, colItems
        Dim ProcessCnt As Integer
        WshShell = CreateObject("WScript.Shell")
        'If InStr(WScript.FullName, "E³") Then
        '    App = WScript                               ' internal
        'Else
        objWMIService = GetObject("winmgmts:\\" & "." & "\root\cimv2")
        colItems = objWMIService.ExecQuery("Select * from Win32_Process", , 48)
        ProcessCnt = 0
        For Each objItem In colItems
            If InStr(objItem.Caption, "E3.series") Then ProcessCnt = ProcessCnt + 1
        Next
        objWMIService = Nothing
        colItems = Nothing
        If ProcessCnt > 1 Then
            MsgBox("Открыто более одного приложения Е³." + vbCrLf + "Невозможно запустить E³.services", MsgBoxStyle.OkOnly, "E³.services")
            'WScript.Quit()
            ConnectToE3 = False
        Else
            App = CreateObject("CT.Application")       ' external
            ConnectToE3 = True
        End If
        'End If
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ConnectToE3()
        Dim T As New E3Type
        Dim AllE3Objects As Hashtable
        AllE3Objects = GetRunningE3Objects()
        If AllE3Objects.Count = 0 Then
            MsgBox("Нет открытого приложения Е³." + vbCrLf + "Завершение работы E³.services ...", vbOKOnly, "Завершение работы E³.services")
            End
        End If

        App = CreateObject("CT.Application") ' Создаём объект app, пока вс5е по умолчанию, невозможно выбрать из нескольких
        Delay(1000)
        App.PutMessage("===== E³.services connection ===========")
        Delay(800)
        App.PutMessage("E³.services is running. " + CStr(Now.TimeOfDay.ToString))

        'App.PutMessage(App.)
        Job = App.CreateJobObject()    ' Создаём объект job
        Dev = Job.CreateDeviceObject
        Sym = Job.CreateSymbolObject
        jobName = Job.GetName
        TextBox1.Text = jobName
        If jobName = "" Then
            ' Выводим сообщение об ошибке
            App.PutMessage("Нет открытого проекта!")
            ' Выходим
            App = Nothing
            MsgBox("Нет открытого проекта." + vbCrLf + "Завершение работы E³.services ...", vbOKOnly, "Завершить работу?")
            End
        End If
        Sheet = Job.CreateSheetObject
        Dim SheetId, ActiveSheetID As Integer
        ActiveSheetID = Job.GetActiveSheetId()
        Sheet.SetId(ActiveSheetID)
        SheetName = Sheet.GetName
        TextBox2.Text = SheetName
        ListBox1.Items.Clear()
        Try
            Dim n As Int32
            n = Job.GetSheetIds(SheetIds)
            Att = New e3.e3Attribute
            For i = 1 To n
                SheetId = SheetIds(i)
                Sheet.SetId(SheetId)
                SheetName = Sheet.GetName

                ListBox1.Items.Add(SheetName + vbTab + Sheet.GetFormat + vbTab)
                If ActiveSheetID = SheetId Then
                    ListBox1.SelectedIndex = i - 1
                End If
            Next
            NumOfDevices = Job.GetAllDeviceIds(DevIds)
            TextBox3.Text = CStr(NumOfDevices - 1)
            NumOfSyms = Job.GetSymbolCount
            TextBox4.Text = CStr(NumOfSyms) + "/"
            NumOfSyms = Job.GetSelectedSymbolIds(SymIds)
            TextBox4.Text = TextBox4.Text + CStr(NumOfSyms)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'TimerUpdate.Enabled = True
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        Dim a As MsgBoxResult, S As String
        S = Job.GetCurrentUserName
        If e.CloseReason <> 3 Then Exit Sub
        a = MsgBox("Завершить работу?", vbOKCancel, "Завершение работы E³.services ...")
        If a = 1 Then
            Delay(400)
            App.PutMessage("===== E³.services connection closed=====")
            Delay(700)
            App.PutMessage("E³.services is stopped. " + Now.TimeOfDay.ToString)
            Delay(500)
            App.PutMessage("Приятной работы!")
            App = Nothing
            Dim fs As New IO.StreamWriter("\\mechanics\spool_ogk\SPOOL\КБ электрооборуд.Перспект\Смирнов\е3.txt", True)
            Try
                fs.WriteLine(TextBox1.Text + "; " + TextBox2.Text + "; " + S + "; " + Now)
                fs.Close()
            Catch ex As Exception

            End Try
        Else
            e.Cancel = True
        End If
    End Sub

    'Private Sub TimerUpdate_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerUpdate.Tick
    '    Dim SheetId, ActiveSheetID As Integer
    '    ActiveSheetID = Job.GetActiveSheetId()
    '    Sheet.SetId(ActiveSheetID)
    '    SheetName = Sheet.GetName
    '    TextBox2.Text = SheetName
    '    Try
    '        Dim n As Int32
    '        n = Job.GetSheetIds(SheetIds)
    '        ListBox1.Items.Clear()
    '        For i = 1 To n
    '            SheetId = SheetIds(i)
    '            Sheet.SetId(SheetId)
    '            SheetName = Sheet.GetName
    '            ListBox1.Items.Add(SheetName)
    '            If ActiveSheetID = SheetId Then
    '                ListBox1.SelectedIndex = i - 1
    '            End If
    '        Next
    '        NumOfDevices = Job.GetAllDeviceIds(DevIds)
    '        TextBox3.Text = CStr(NumOfDevices - 1)
    '    Catch
    '        MsgBox("")
    '    End Try
    'End Sub

    Public Sub But1_Clk()
        Dim ee As New System.EventArgs
        Button1_Click(Me, ee)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ViewDevises Then Exit Sub
        Form2.Visible = True
        Try
            Dim devId As Integer ', Cab As Integer
            NumOfDevices = Job.GetAllDeviceIds(DevIds)

            TextBox3.Text = CStr(NumOfDevices - 1)
            Form2.ListBox1.Items.Clear()
            For i = 1 To NumOfDevices '- 1
                devId = DevIds(i)
                Dev.SetId(devId)
                'Cab = Dev.IsDevice
                'If Cab = 1 Then
                Form2.ListBox1.Items.Add(Dev.GetName + vbTab + Dev.GetComponentName)
            Next
        Catch
            MsgBox("")
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ViewSymbols Then Exit Sub
        Form4.Visible = True

        Dim SymId As Integer
        NumOfSyms = Job.GetSymbolCount
        TextBox4.Text = CStr(NumOfSyms) + "/"
        NumOfSyms = Job.GetSelectedSymbolIds(SymIds)
        TextBox4.Text = TextBox4.Text + CStr(NumOfSyms)
        Form4.ListBox1.Items.Clear()
        For i = 1 To NumOfSyms '- 1
            SymId = SymIds(i)
            Sym.SetId(SymId)
            Form4.ListBox1.Items.Add(Sym.GetName + vbTab + Sym.GetSymbolTypeName)
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim ActiveSheetID As Integer, i As Integer
        i = ListBox1.SelectedIndex + 1
        ActiveSheetID = SheetIds(i)
        Sheet.SetId(ActiveSheetID)
        Sheet.Display()
        SheetName = Sheet.GetName
        TextBox2.Text = SheetName
        App.PutMessage("Текущий лист - " + SheetName)
        If OutDiag Then
            Dim s As String
            Dim k As Integer = Sheet.GetAttributeIds(AttributeIds)
            Form3.addText("===============================================")
            For j = 1 To k
                Att.SetId(AttributeIds(j))
                s = Att.GetName + ":" + vbTab + Att.GetValue

                Form3.addText(s)
            Next
        End If
    End Sub

    '=================================================================================================================
    '                                             КУСОК ДЛЯ РЕАЛИЗАЦИИ ЗАДЕРЖКИ                                      =
    Dim TimeDelay As Boolean = False '================================================================================
    Sub Delay(ByVal T As Integer) '===================================================================================
        Timer1.Interval = T / 2 '                                                                                    =
        Timer1.Enabled = True '                                                                                      =

        Do Until TimeDelay '                                                                                         =
            Application.DoEvents() '                                                                                 =
        Loop '                                                                                                       =
        TimeDelay = False '                                                                                          =
    End Sub '                                                                                                        =
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick '        =
        TimeDelay = True '                                                                                           =
        Timer1.Enabled = False '                                                                                     =
    End Sub '                                                                                                        =
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        OutDiag = CheckBox1.Checked
        Form3.Visible = OutDiag
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim sig As New e3Signal
        Form5Core.Visible = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim fwi = New FLASHWINFO With {
            .cbSize = Marshal.SizeOf(GetType(FLASHWINFO)),
            .hwnd = Me.Handle,
            .dwFlags = FLASH_TYPE.Tray,
            .uCount = 1 '1 - постоянное свечение, 2+ - кол-во морганий
            }
        FlashWindowEx(fwi)

        Dim ConnId, k As Integer, s As String
        NumOfConns = Job.GetBundleIds(ConnIds)
        For i = 1 To NumOfConns
            ConnId = ConnIds(i)
            Conn.SetId(ConnId)
            Form3.AddText(Conn.GetName + vbTab + CStr(Conn.GetPinCount))
            k = Conn.GetAttributeIds(AttributeIds)
            Form3.AddText("===============================================")
            For j = 1 To k
                Att.SetId(AttributeIds(j))
                s = Att.GetName + ":" + vbTab + Att.GetValue

                Form3.AddText(s)
                Application.DoEvents()
            Next
        Next

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim sig As New e3Signal
        Form5sech.Visible = True
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.F1 Then AboutBox1.Visible = True
    End Sub
End Class