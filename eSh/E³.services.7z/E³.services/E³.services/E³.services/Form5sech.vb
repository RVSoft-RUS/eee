﻿Public Class Form5sech
    Dim Scale_, H_ As Single
    Dim idf, idl As Integer
    Dim Sht As New e3.e3Sheet 'Лист E3

    Public NetSegment As New e3.e3NetSegment 'сегм
    Public NetSegIds()  'Массив id сегм 
    Public NumOfNetSegs As Integer ' кол-во сегм

    Public Core As New e3.e3Pin
    Public CoreIds()  'Массив id символов 
    Public NumOfCores As Integer ' кол-во символов
    Public AllCoreIds()  'Массив id символов 

    Dim eSheet As New e3.e3Sheet 'Лист E3
    Dim embSheetIds()  'Массив id листов 
    Dim NumOfeSheets As Integer

    Dim Sym As New e3.e3Symbol
    Dim Dv As e3.e3Device

    Dim Graph As New e3.e3Graph
    Dim GraphIds()  'Массив id graphs 
    Dim NumOfGraph As Integer
    Dim Group As New e3.e3Group
    Dim ItemIds()
    Dim ItemsCount As Integer

    Dim Line As New e3.e3ConnectLine

    Structure AllLines
        Dim x1 As Integer
        Dim x2 As Integer
        Dim y1 As Integer
        Dim y2 As Integer
        Dim sech As Single
        Dim Sign As String
    End Structure
    Dim A_lines() As AllLines
    Dim S_tt As String = "", X_f, Y_f As Integer
    Dim DoNotPaintGraph As Integer = 0

    Private Sub Form5sech_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim NC As Integer, S As String
        ComboBox1.Items.Clear()
        Dim X1, Y1, X2, Y2, r As Single
        S = Form1.Sheet.GetName
        S = S + " - " + Form1.Sheet.GetFormat
        Me.Text = Me.Text + " (" + S + ")"
        r = Form1.Sheet.GetWorkingArea(X1, Y1, X2, Y2)
        'Сделать размеры формы пропорционально рабочей области
        Dim Wmax, Hmax As Integer, Rt As Rectangle
        Rt = Screen.GetWorkingArea(Me)
        Wmax = Rt.Width
        Hmax = Rt.Height 'Макс размеры формы
        Dim W, H As Integer
        W = X2 - X1
        H = Y2 - Y1
        H_ = H
        X1 = W / Wmax
        Y1 = H / Hmax
        r = X1
        If Y1 > r Then r = Y1
        Scale_ = r
        Me.Top = 0
        Me.Left = 0
        Me.Width = W / r
        Me.Height = H / r + 25
        ReDim Preserve AllCoreIds(0)
        NumOfeSheets = Form1.Sheet.GetEmbeddedSheetIds(embSheetIds)
        For i = 1 To NumOfeSheets
            eSheet.SetId(embSheetIds(i))
            idf = eSheet.GetId
        Next ' Нижний кусок надо вложить в этот цикл, но Embeded только один лист поэтому пох
        NumOfNetSegs = eSheet.GetNetSegmentIds(NetSegIds)
        For j = 1 To NumOfNetSegs 'Заполнение масссива цепей
            NetSegment.SetId(NetSegIds(j))
            ListBox1.Items.Add(NetSegment.GetSignalName + "*" + CStr(NetSegIds(j)))
            NumOfCores = NetSegment.GetCoreIds(CoreIds)
            For k = 1 To NumOfCores
                If Not AlreadyInMassive(CoreIds(k)) Then
                    NC = NC + 1
                    ReDim Preserve AllCoreIds(NC)
                    AllCoreIds(NC) = CoreIds(k)
                    Core.SetId(AllCoreIds(NC))
                    S = Core.GetSignalName
                    If Not ComboBox1.Items.Contains(S) Then
                        ComboBox1.Items.Add(Core.GetSignalName)
                    End If
                End If


            Next
        Next
        '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        ComboBox1.Items.Add("*Все цепи")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Me.Refresh()
        Dim Si, S, Name, rot As String, N, Ns, L As Integer, len As Double
        Dim Xarr(), Yarr(), Zarr(), LIds(), SymIds()
        ReDim Xarr(0), Yarr(0), Zarr(0), LIds(0), SymIds(0), A_lines(0)
        Dim numlin As Integer
        Dim g As Graphics = Me.CreateGraphics
        Dim c As Color
        Dim w As Single
        Dim br As New SolidBrush(Color.Red)
        Dim p As Pen
        Dim Font As New Font("Arial", 10)
        Dim x1, y1, x2, y2, xS, yS As Integer
        Dim tmpSheet As New e3.e3Sheet
        Name = Form1.Sheet.GetFormat
        tmpSheet = Form1.Job.CreateSheetObject 'Лист не создается
        tmpSheet.Create(0, "tmpSheet", Name, 0, 0)
        tmpSheet.Display()

        Si = ComboBox1.Text
        ListBox1.Items.Clear()
        If Form1.OutDiag Then
            Form3.AddText("_______________________________________________")
            Form3.AddText("Выбрана цепь: " + Si)
        End If

        For k = 1 To AllCoreIds.Length - 1
            Core.SetId(AllCoreIds(k))
            S = Core.GetSignalName

            If S = Si Or Si = "*Все цепи" Then
                'Все Core с выбранным именем
                N = N + 1
                'Core - здесь один из проводов c указанным именем цепи
                len = len + Core.GetLength
                'TextBox1.Text = TextBox1.Text + vbNewLine + "Core.GetLength=" + CStr(Core.GetLength)
                'TextBox1.Text = TextBox1.Text + vbNewLine + "Core.GetNetSegmentCount=" + CStr(Core.GetNetSegmentCount)
                NumOfNetSegs = Core.GetNetSegmentIds(NetSegIds)
                c = Color.FromArgb(Rnd() * 225, Rnd() * 225, Rnd() * 225)
                w = Cross(Core.GetCrossSection)
                p = New Pen(c, w)
                xS = Math.Round(Rnd() * 12 - 6, 0)
                yS = Math.Round(Rnd() * 12 - 6, 0) + 50
                For i = 1 To NumOfNetSegs
                    ListBox1.Items.Add(Core.GetSignalName + "*" + CStr(NetSegIds(i)))
                    'NetSegment - часть провода от Core
                    NetSegment.SetId(NetSegIds(i))
                    L = NetSegment.GetConnectLineIds(LIds)

                    For j = 1 To L

                        idl = Line.SetId(LIds(j))
                        idl = Sht.SetId(idl)
                        idl = Sht.GetId
                        If idl <> idf Then
                            GoTo ExtFor
                        End If
                        Line.GetCoordinates(Xarr, Yarr, Zarr)
                        x1 = CInt(Xarr(1) / Scale_)
                        x2 = CInt(Xarr(2) / Scale_)
                        'If x1 = x2 Then xS = Math.Round(Rnd() * 8 - 4, 0)
                        y1 = CInt((H_ - Yarr(1)) / Scale_)
                        y2 = CInt((H_ - Yarr(2)) / Scale_)
                        'If y1 = y2 Then yS = Math.Round(Rnd() * 8 - 4, 0)
                        g.DrawLine(p, x1 + xS, y1 + yS, x2 + xS, y2 + yS)
                        numlin = numlin + 1
                        ReDim Preserve A_lines(numlin)
                        A_lines(numlin).x1 = x1
                        A_lines(numlin).x2 = x2
                        A_lines(numlin).y1 = y1
                        A_lines(numlin).y2 = y2
                        A_lines(numlin).sech = Core.GetCrossSection
                        A_lines(numlin).Sign = " - " + S
                    Next
                    L = NetSegment.GetConnectedSymbolIds(SymIds)
                    For j = 1 To L
                        Dv = Form1.Job.CreateDeviceObject
                        Graph = Form1.Job.CreateGraphObject
                        Dv.SetId(SymIds(j)) 'перейти к изделию, прямым переходом и спросить у изделия
                        Sym.SetId(SymIds(j))
                        Name = Dv.GetName 'перейти к изделию, прямым переходом и спросить у изделия
                        Sym.GetPlacedArea(x1, y1, x2, y2)
                        rot = Sym.GetRotation
                        Name = Sym.GetType 'тут не работает
                        Sym.GetPlacedArea(x1, y1, x2, y2)
                        Graph.CreateFromSymbol(tmpSheet.GetId, x2, y2, rot, 1, 1, Name, "")
                        x1 = (x1 + x2) / 2
                        y1 = (y1 + y2) / 2
                        x1 = CInt(x1 / Scale_)
                        y1 = CInt((H_ - y1) / Scale_)
                        g.DrawString(Name, Font, br, x1, y1)

                    Next
                    Ns = Ns + 1
ExtFor:
                Next
            End If

        Next
        NumOfGraph = tmpSheet.GetGraphIds(GraphIds)
        p = New Pen(Color.LightGray, 1)
        Dim tId As Integer, txt As String, grid As Object
        For j = 1 To NumOfGraph
            Graph.SetId(GraphIds(j))
            tId = Graph.GetTypeId()
            Application.DoEvents()
            If DoNotPaintGraph = 1 Then GoTo ExGra
            Select Case tId
                Case 1
                    Graph.GetLine(x1, y1, x2, y2)
                    x1 = CInt(x1 / Scale_) - 20
                    x2 = CInt(x2 / Scale_) - 20
                    y1 = CInt((H_ - y1) / Scale_) + 70
                    y2 = CInt((H_ - y2) / Scale_) + 70
                    g.DrawLine(p, x1, y1, x2, y2)
                Case 6
                    Group.SetId(GraphIds(j))
                    ItemsCount = Graph.GetGraphIds(ItemIds)
                    For k = 1 To ItemsCount
                        Graph.SetId(ItemIds(k))
                        tId = Graph.GetTypeId()
                        Select Case tId
                            Case 1
                                Graph.GetLine(x1, y1, x2, y2)
                                x1 = CInt(x1 / Scale_) - 20
                                x2 = CInt(x2 / Scale_) - 20
                                y1 = CInt((H_ - y1) / Scale_) + 70
                                y2 = CInt((H_ - y2) / Scale_) + 70
                                g.DrawLine(p, x1, y1, x2, y2)
                            Case 4
                                Graph.GetCircle(x1, y1, x2)
                                x1 = CInt(x1 / Scale_) - 20
                                x2 = x2 / Scale_
                                y1 = CInt((H_ - y1) / Scale_) + 70
                                x1 = x1 - x2
                                y1 = y1 - x2
                                g.DrawEllipse(p, x1, y1, x2 * 2, x2 * 2)
                            Case 5
                                Graph.GetArc(x1, y1, grid, x2, y2)
                                x1 = CInt(x1 / Scale_) - 20
                                grid = grid / Scale_
                                If grid < 0.5 Then grid = 0.5
                                y1 = CInt((H_ - y1) / Scale_) + 70
                                x1 = CInt(x1 - grid)
                                y1 = CInt(y1 - grid)
                                If x2 > 360 Then x2 = x2 - 360
                                If y2 > 360 Then y2 = y2 - 360
                                If x2 > 360 Then x2 = x2 - 360
                                If y2 > 360 Then y2 = y2 - 360
                                g.DrawArc(p, x1, y1, CInt(grid * 2), CInt(grid * 2), y2, x2)
                            Case 8
                                txt = Graph.GetText()
                                Graph.GetTextLeftJustifiedSchemaLocation(x1, y1, grid)
                                x1 = CInt(x1 / Scale_) - 20
                                y1 = CInt((H_ - y1) / Scale_) + 70
                                br.Color = Color.Gray
                                g.DrawString(txt, Font, br, x1, y1)
                        End Select
                    Next
                Case 8
                    txt = Graph.GetText()
                    Graph.GetTextLeftJustifiedSchemaLocation(x1, y1, grid)
                    x1 = CInt(x1 / Scale_) - 20
                    y1 = CInt((H_ - y1) / Scale_) + 70
                    br.Color = Color.Gray
                    g.DrawString(txt, Font, br, x1, y1)
            End Select

        Next
ExGra:
        DoNotPaintGraph = 0
        tmpSheet.Delete()
        g.Dispose()
    End Sub
    Private Sub ListBox1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles ListBox1.MouseDoubleClick
        Dim S As String, k As Integer
        S = ListBox1.SelectedItem
        k = InStrRev(S, "*")
        S = S.Substring(k)
        k = CInt(S)
        Form1.Job.JumpToID(k)
        If Form1.OutDiag Then
            NetSegment.SetId(k)
            Form3.AddText("| Выбран сегмент: " + CStr(k))
            Form3.AddText("| Длина сегмента: " + CStr(NetSegment.GetLength))
        End If
    End Sub

    Private Function AlreadyInMassive(N As Integer) As Boolean
        For k = 1 To AllCoreIds.Length - 1
            If AllCoreIds(k) = N Then Return True
        Next
        Return False
    End Function
    Private Function Cross(S As Single) As Single
        Select Case S
            Case <= 0.75
                Return 1
            Case <= 1
                Return 2
            Case <= 1.5
                Return 3
            Case <= 2.5
                Return 4
            Case <= 4
                Return 5
            Case <= 6
                Return 6
            Case Else
                Return 7
        End Select
    End Function

    Private Sub Form5sech_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Dim S As String = ""
        Dim L, L1, L2 As Single
        X_f = e.X
        Y_f = e.Y - 50
        Try
            For i = 1 To A_lines.Length - 1
                L = Math.Sqrt(Math.Pow((A_lines(i).x1 - A_lines(i).x2), 2) + Math.Pow((A_lines(i).y1 - A_lines(i).y2), 2))
                L1 = Math.Sqrt(Math.Pow((A_lines(i).x1 - X_f), 2) + Math.Pow((A_lines(i).y1 - Y_f), 2))
                L2 = Math.Sqrt(Math.Pow((A_lines(i).x2 - X_f), 2) + Math.Pow((A_lines(i).y2 - Y_f), 2))
                If L1 + L2 < L + 6 Then
                    S = S + CStr(A_lines(i).sech) + A_lines(i).Sign + vbNewLine
                Else

                End If
            Next
            'ToolTip1.SetToolTip(Me, S)
            S_tt = S
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form5sech_Click(sender As Object, e As EventArgs) Handles Me.Click
        Dim g As Graphics = Me.CreateGraphics
        Dim br As New SolidBrush(Color.White)
        Dim Font As New Font("Arial", 6)
        Dim p As New Pen(Color.DarkGreen, 1)
        g.DrawString(S_tt, Font, br, X_f, Y_f + 50)
        br.Color = (Color.Black)
        g.DrawString(S_tt, Font, br, X_f + 1, Y_f + 1 + 50)
        g.DrawEllipse(p, X_f - 3, Y_f - 3 + 50, 6, 6)
        g.Dispose()
    End Sub

    Private Sub Form5sech_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F3 Then
            DoNotPaintGraph = 1
        End If
    End Sub

    Private Sub ComboBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles ComboBox1.KeyUp
        If e.KeyCode = Keys.F3 Then
            DoNotPaintGraph = 1
            Dim g As Graphics = Me.CreateGraphics
            Dim br As New SolidBrush(Color.PaleGreen)
            Dim Font As New Font("Arial", 7)
            g.DrawString("Не рисовать графику", Font, br, 160, 6)
            g.Dispose()
        End If

    End Sub
End Class