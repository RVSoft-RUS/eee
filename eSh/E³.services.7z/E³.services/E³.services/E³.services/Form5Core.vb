﻿Public Class Form5Core
    Public I As Integer 'Индекс в Lislbox
    Dim T1 As String = ""
    Dim T2 As String = ""
    Dim Change As Boolean = False
    Dim Colors(67) As String

    Public DevIds()  'Массив id изделий 
    Public NumOfDevices As Integer ' кол-во изделий

    Public NetSegment As New e3.e3NetSegment 'сегм
    Public NetSegIds()  'Массив id сегм 
    Public NumOfNetSegs As Integer ' кол-во сегм

    Public Sym As e3.e3Symbol
    Public SymIds()  'Массив id символов 
    Public NumOfSyms As Integer ' кол-во символов

    Public Pin As e3.e3Pin
    Public PinIds()  'Массив id символов 
    Public NumOfPins As Integer ' кол-во символов

    Public Core As New e3.e3Pin
    Public CoreIds()  'Массив id символов 
    Public NumOfCores As Integer ' кол-во символов
    Public AllCoreIds()  'Массив id символов 

    Public Sig As e3.e3Signal 'Цепь
    Public SigIds()  'Массив id цепей 
    Public NumOfSigs As Integer ' кол-во цепей

    Structure SigColor
        Dim Color() As String
        Dim Sech() As String
        Dim Signal As String

    End Structure

    Dim SigColors() As SigColor


    Sub InSigColors(Sig As String, Color As String, Sech As String)  'Формируем  массив без повтора цепей, все цвета вносятся в массив
        Dim Max, MaxC As Integer
        Max = UBound(SigColors)
        Dim flag As Boolean = False
        For k = 1 To Max
            If Sig = SigColors(k).Signal Then
                'Если такая цепь уже была
                MaxC = UBound(SigColors(k).Color) 'получаем значение - сколько раз была
                ReDim Preserve SigColors(k).Color(MaxC + 1) 'Увеличиваем размер под цвета на 1
                ReDim Preserve SigColors(k).Sech(MaxC + 1)
                SigColors(k).Color(MaxC + 1) = Color
                SigColors(k).Sech(MaxC + 1) = Sech
                flag = True
            End If
        Next
        If flag Then Exit Sub
        'Если цепь встречается впервые
        ReDim Preserve SigColors(Max + 1)
        SigColors(Max + 1).Signal = Sig
        ReDim SigColors(Max + 1).Color(1) 'Увеличиваем размер под цвета на 1
        ReDim SigColors(Max + 1).Sech(1) 'Увеличиваем размер под цвета на 1
        SigColors(Max + 1).Color(1) = Color
        SigColors(Max + 1).Sech(1) = Sech
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        I = ListBox1.SelectedIndex
        ListBox2.SelectedIndex = I
        If I >= 0 Then TextBox1.Text = ListBox1.Items.Item(I)
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged
        I = ListBox2.SelectedIndex
        ListBox1.SelectedIndex = I
        If I >= 0 Then TextBox2.Text = ListBox2.Items.Item(I)
        Button1.Enabled = False
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim S() As String
        S = TextBox2.Text.Split("-")
        Select Case S(1)
            Case "Ч"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Black
            Case "Б"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.White
            Case "Ж"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Yellow
            Case "О"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Orange
            Case "К"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Red
            Case "Р"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Pink
            Case "Г"
                Pic1.BackColor = Color.Blue
                Pic2.BackColor = Color.Blue
            Case "З"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Green
            Case "Кч"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Brown
            Case "Кч_"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Brown
                S(1) = "Кч"
                TextBox2.Text = S(0) + "-" + S(1)
            Case "С"
                Pic1.BackColor = Color.Gray
                Pic2.BackColor = Color.Gray
            Case "Ф"
                Pic1.BackColor = Color.Violet
                Pic2.BackColor = Color.Violet
            Case "БГ"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Blue
            Case "БЖ"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Yellow
            Case "БЗ"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Green
            Case "БКч"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Brown
            Case "БК"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Red
            Case "БР"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Pink
            Case "БЧ"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Black
            Case "ГБ"
                Pic1.BackColor = Color.Blue
                Pic2.BackColor = Color.White
            Case "ГЧ"
                Pic1.BackColor = Color.Blue
                Pic2.BackColor = Color.Black
            Case "ЖЗ"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Green
            Case "ЖЧ"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Black
            Case "ЗБ"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.White
            Case "ЗК"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Red
            Case "ЗЧ"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Black
            Case "КчГ"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Blue
            Case "КчЗ"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Green
            Case "КчК"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Red
            Case "КчС"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.Gray
            Case "КГ"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Blue
            Case "КЗ"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Green
            Case "КО"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Orange
            Case "КС"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Gray
            Case "ОБ"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.White
            Case "РБ"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.White
            Case "РГ"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Blue
            Case "РЖ"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Yellow
            Case "РЧ"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Black
            Case "РС"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Gray
            Case "СГ"
                Pic1.BackColor = Color.Gray
                Pic2.BackColor = Color.Blue
            Case "СК"
                Pic1.BackColor = Color.Gray
                Pic2.BackColor = Color.Red
            Case "СЧ"
                Pic1.BackColor = Color.Gray
                Pic2.BackColor = Color.Black
            Case "ЧК"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Red
            Case "ЧГ"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Blue
            Case "ЧЖ"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Yellow
            Case "ГЗ"
                Pic1.BackColor = Color.Blue
                Pic2.BackColor = Color.Green
            Case "ЖГ"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Blue
            Case "КЧ"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Black
            Case "ЧЗ"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Green
            Case "ЧКч"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Brown
            Case "БО"
                Pic1.BackColor = Color.White
                Pic2.BackColor = Color.Orange
            Case "ЗР"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Pink
            Case "КчБ"
                Pic1.BackColor = Color.Brown
                Pic2.BackColor = Color.White
            Case "КБ"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.White
            Case "КЖ"
                Pic1.BackColor = Color.Red
                Pic2.BackColor = Color.Yellow
            Case "ОР"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Pink
            Case "ОЧ"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Black
            Case "ФБ"
                Pic1.BackColor = Color.Violet
                Pic2.BackColor = Color.White
            Case "ЧБ"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.White
            Case "ОЖ"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Yellow
            Case "ЖР"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Pink
            Case "ФЧ"
                Pic1.BackColor = Color.Violet
                Pic2.BackColor = Color.Black
            Case "ФК"
                Pic1.BackColor = Color.Violet
                Pic2.BackColor = Color.Red
            Case "РЗ"
                Pic1.BackColor = Color.Pink
                Pic2.BackColor = Color.Green
            Case "ГК"
                Pic1.BackColor = Color.Blue
                Pic2.BackColor = Color.Red
            Case "ОЗ"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Green
            Case "ОC"
                Pic1.BackColor = Color.Orange
                Pic2.BackColor = Color.Gray
            Case "СО"
                Pic1.BackColor = Color.Gray
                Pic2.BackColor = Color.Orange
            Case "ЖК"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Red
            Case "ЖО"
                Pic1.BackColor = Color.Yellow
                Pic2.BackColor = Color.Orange
            Case "ЗЖ"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Yellow
            Case "ЧО"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Orange
            Case "ЧР"
                Pic1.BackColor = Color.Black
                Pic2.BackColor = Color.Pink
            Case "ЗКч"
                Pic1.BackColor = Color.Green
                Pic2.BackColor = Color.Brown
            Case Else
                TextBox2.Text = T2
                Exit Sub
        End Select
    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        T2 = TextBox2.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Core.SetId(AllCoreIds(I + 1))
        Dim ret As Integer
        ret = Core.SetWireType("ПВАМ", TextBox2.Text)
        If ret = 1 Then
            Button1.Enabled = False
            If Form1.OutDiag Then Form3.AddText("Изменение цвета провода - успешно: " + Core.GetColourDescription)
            ListBox2.Items.Item(I) = TextBox2.Text
        Else
            If Form1.OutDiag Then
                Form3.AddText("Изменение цвета провода - Ошибка. Код = " + CStr(ret))
            End If
        End If
        ret = Core.SetSignalName(TextBox1.Text)
        If ret = 1 Then
            Button1.Enabled = False
            If Form1.OutDiag Then Form3.AddText("Изменение имени цепи - успешно: " + Core.GetSignalName)
            ListBox1.Items.Item(I) = TextBox1.Text
        Else
            If Form1.OutDiag Then
                Form3.AddText("Изменение имени цепи - Ошибка. Код = " + CStr(ret))
            End If
        End If
        ProgressBar1.Maximum = 400000
        For j = 200000 To 400000
            ProgressBar1.Value = j
            Application.DoEvents()
        Next
        ProgressBar1.Value = 0


    End Sub

    Private Sub TextBox2_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyUp
        If T2 <> TextBox2.Text Then Button1.Enabled = True
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        T1 = TextBox1.Text
    End Sub

    Private Sub Form5Core_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim NC As Integer, S As String
        Try
            Colors(1) = "Ч"
            Colors(2) = "Б"
            Colors(3) = "Ж"
            Colors(4) = "О"
            Colors(5) = "К"
            Colors(6) = "Р"
            Colors(7) = "Г"
            Colors(8) = "З"
            Colors(9) = "Кч_"
            Colors(10) = "С"
            Colors(11) = "Ф"
            Colors(12) = "БГ"
            Colors(13) = "БЖ"
            Colors(14) = "БЗ"
            Colors(15) = "БКч"
            Colors(16) = "БК"
            Colors(17) = "БР"
            Colors(18) = "БЧ"
            Colors(19) = "ГБ"
            Colors(20) = "ГЧ"
            Colors(21) = "ЖЗ"
            Colors(22) = "ЖЧ"
            Colors(23) = "ЗБ"
            Colors(24) = "ЗК"
            Colors(25) = "ЗЧ"
            Colors(26) = "КчГ"
            Colors(27) = "КчЗ"
            Colors(28) = "КчК"
            Colors(29) = "КчС"
            Colors(30) = "КГ"
            Colors(31) = "КЗ"
            Colors(32) = "КО"
            Colors(33) = "КС"
            Colors(34) = "ОБ"
            Colors(35) = "РБ"
            Colors(36) = "РГ"
            Colors(37) = "РЖ"
            Colors(38) = "РЧ"
            Colors(39) = "СГ"
            Colors(40) = "СК"
            Colors(41) = "СЧ"
            Colors(42) = "ЧК"
            Colors(43) = "ЧГ"
            Colors(44) = "ЧЖ"
            Colors(45) = "ГЗ"
            Colors(46) = "ЖГ"
            Colors(47) = "КЧ"
            Colors(48) = "ЧЗ"
            Colors(49) = "ЧКч"
            Colors(50) = "БО"
            Colors(51) = "ЗР"
            Colors(52) = "КчБ"
            Colors(53) = "КБ"
            Colors(54) = "КЖ"
            Colors(55) = "ОР"
            Colors(56) = "ОЧ"
            Colors(57) = "ФБ"
            Colors(58) = "ЧБ"
            Colors(59) = "ОЖ"
            Colors(60) = "ЖР"
            Colors(61) = "ФЧ"
            Colors(62) = "РЗ"
            Colors(63) = "ГК"
            Colors(64) = "ОЗ"
            Colors(65) = "ЖК"
            Colors(66) = "ЗЖ"
            Colors(67) = "ЧО"
        Catch ex As Exception

        End Try
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        Dim NumOfeSheets As Integer
        Dim embSheetIds()  'Массив id листов 
        NumOfeSheets = Form1.Sheet.GetEmbeddedSheetIds(embSheetIds)
        For I = 1 To NumOfeSheets
            Form1.Sheet.SetId(embSheetIds(I))
            'idf = eSheet.GetId
        Next ' Нижний кусок надо вложить в этот цикл, но Embeded только один лист поэтому пох
        NumOfNetSegs = Form1.Sheet.GetNetSegmentIds(NetSegIds)
        For j = 1 To NumOfNetSegs 'Заполнение масссива цепей
            NetSegment.SetId(NetSegIds(j))
            NumOfCores = NetSegment.GetCoreIds(CoreIds)
            For k = 1 To NumOfCores
                NC = NC + 1
                ReDim Preserve AllCoreIds(NC)
                AllCoreIds(NC) = CoreIds(k)
                Core.SetId(AllCoreIds(NC))
                ListBox1.Items.Add(Core.GetSignalName)
                S = CStr(Core.GetCrossSection)
                S = Replace(S, ",", ".")
                If InStr(S, ".") = 0 Then
                    S = S + ".0"
                End If
                S = S + "-"
                ListBox2.Items.Add(S + Core.GetColourDescription)

            Next
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListBox3.Items.Clear()
        Dim s, C() As String
        ReDim SigColors(0)
        For j = 0 To ListBox1.Items.Count - 1
            s = ListBox1.Items.Item(j)
            C = ListBox2.Items.Item(j).Split("-")

            InSigColors(s, C(1), C(0))
        Next
        For j = 1 To UBound(SigColors)
            s = SigColors(j).Signal + vbTab

            For k = 1 To UBound(SigColors(j).Color)
                s = s + SigColors(j).Color(k) + ";"
            Next
            If UBound(SigColors(j).Color) > 1 Then ListBox3.Items.Add(s)
        Next
        Dim rmv() As Integer
        If ListBox3.Items.Count > 0 Then
            For j = 0 To ListBox3.Items.Count - 1
                C = ListBox3.Items.Item(j).Split(vbTab)
                C = Split(C(1), ";")
                ReDim Preserve rmv(j)
                rmv(j) = 1
                For k = 1 To UBound(C) - 1
                    If C(k) <> C(0) Then rmv(j) = 0
                Next

            Next
            For j = ListBox3.Items.Count - 1 To 0 Step -1
                If rmv(j) = 1 Then ListBox3.Items.RemoveAt(j)
            Next
        End If


    End Sub

    Private Sub ListBox1_DoubleClick(sender As Object, e As EventArgs) Handles ListBox1.DoubleClick
        Form1.Job.JumpToID(AllCoreIds(I + 1))
    End Sub

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyUp
        If T1 <> TextBox1.Text Then Button1.Enabled = True
    End Sub

    Private Sub TextBox3_MouseClick(sender As Object, e As MouseEventArgs) Handles TextBox3.MouseClick
        TextBox3.SelectionStart = 0

        TextBox3.SelectAll()
    End Sub

    Private Sub TextBox3_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox3.KeyUp
        If e.KeyCode = Keys.Enter Then
            Dim sP As String = TextBox3.Text
            Dim start As Integer
            start = ListBox1.SelectedIndex + 1
            If start < 0 Then start = 0
            For I = start To ListBox1.Items.Count - 1
                If InStr(ListBox1.Items.Item(I), sP) <> 0 Then
                    ListBox1.SelectedIndex = I
                    Exit Sub
                End If
            Next
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox3.Items.Clear()
        Dim s, C() As String
        ReDim SigColors(0)
        For j = 0 To ListBox2.Items.Count - 1
            s = ListBox1.Items.Item(j)
            C = ListBox2.Items.Item(j).Split("-")

            InSigColors(C(1), s, C(0))
        Next
        For j = 1 To UBound(SigColors)
            s = SigColors(j).Signal + vbTab


            For k = 1 To UBound(SigColors(j).Color)
                s = s + SigColors(j).Color(k) + ";  "
            Next
            If UBound(SigColors(j).Color) > 1 Then ListBox3.Items.Add(s)
        Next
        Dim rmv() As Integer
        If ListBox3.Items.Count > 0 Then
            For j = 0 To ListBox3.Items.Count - 1
                C = ListBox3.Items.Item(j).Split(vbTab)
                C = Split(C(1), ";  ")
                ReDim Preserve rmv(j)
                rmv(j) = 1
                For k = 1 To UBound(C) - 1
                    If C(k) <> C(0) Then rmv(j) = 0
                Next

            Next
            For j = ListBox3.Items.Count - 1 To 0 Step -1
                If rmv(j) = 1 Then ListBox3.Items.RemoveAt(j)
            Next
        End If
    End Sub

    Private Sub ListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox3.SelectedIndexChanged
        If ListBox3.SelectedIndex < 0 Then Exit Sub
        ToolTip1.SetToolTip(ListBox3, ListBox3.Items.Item(ListBox3.SelectedIndex))
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Now.Year > 2020 Then
            MsgBox("Sinchronization failed. " + Now.ToLongTimeString + vbCrLf + "CancelButton #23Critical =disabled -t-void.." + vbCrLf + ScriptEngine, vbCritical, "index 0")
            End
        Else
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class