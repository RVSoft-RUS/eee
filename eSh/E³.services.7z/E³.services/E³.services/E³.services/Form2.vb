﻿Public Class Form2
    Dim devId As Integer

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        Form1.Job.JumpToID(devId)

        Form1.App.PutMessage("Изделие - " + Form1.Dev.GetName + vbTab + Form1.Dev.GetComponentName)
        If Form1.OutDiag Then
            Dim s As String
            Dim k As Integer = Form1.Dev.GetAttributeIds(Form1.AttributeIds)
            Form3.addText("_______________________________________________")
            For j = 1 To k
                Form1.Att.SetId(Form1.AttributeIds(j))
                s = Form1.Att.GetName + ":" + vbTab + Form1.Att.GetValue
                Form3.addText(s)
            Next
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim i As Integer
        i = ListBox1.SelectedIndex + 1
        devId = Form1.DevIds(i)
        Form1.Dev.SetId(devId)

    End Sub

    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Form1.ViewDevises = False
    End Sub

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Form1.ViewDevises = True
    End Sub

    Private Sub ListBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles ListBox1.MouseUp
        If e.Button = MouseButtons.Right Then
            Dim P As Point
            P.X = 12
            P.Y = 32
            Me.ContextMenu1.Show(Me.Location + e.Location + P)
        End If
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        FormDevP.Visible = True 'Редактировать
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        'Удалить
        Dim a As MsgBoxResult, r As Integer, s As String
        s = Form1.Dev.GetName + " / " + Form1.Dev.GetComponentName
        a = MsgBox(s + vbCrLf + "Уверены, что хотите удалить указанное изделие?", vbOKCancel, "Предупреждение")
        If a = vbCancel Then Exit Sub
        r = Form1.Dev.Delete()
        Form1.ViewDevises = False
        Form1.But1_Clk()
        If Form1.OutDiag Then
            If r = 1 Then Form3.addText(Now + " Удалено изделие: " + s)
            If r = 0 Then Form3.addText(Now + " Изделие: " + s + " не может быть удалено из проекта (используется=1)")
        End If
        If r = 1 Then Form1.App.PutMessage("Удалено изделие: " + s)
    End Sub

    Private Sub УдалитьНеиспользуемыеToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles УдалитьНеиспользуемыеToolStripMenuItem.Click
        'Удалить все
        Dim a As MsgBoxResult, r As Integer, s As String
        a = MsgBox("Будут удалены все неиспользуемые в проекте изделия. Продолжить?", vbOKCancel, "Предупреждение")
        If a = vbCancel Then Exit Sub
        For i = 1 To Form1.NumOfDevices
            Form1.Dev.SetId(Form1.DevIds(i))
            s = Form1.Dev.GetName + " / " + Form1.Dev.GetComponentName
            r = Form1.Dev.Delete()
            If Form1.OutDiag Then
                If r = 1 Then Form3.addText(Now + " Удалено изделие: " + s)
                If r = 0 Then Form3.addText(Now + " Изделие: " + s + " не может быть удалено из проекта (используется=1)")
            End If
            If r = 1 Then Form1.App.PutMessage("Удалено изделие: " + s)
        Next

        Form1.ViewDevises = False
        Form1.But1_Clk()


    End Sub

    Private Sub TextBox1_MouseClick(sender As Object, e As MouseEventArgs) Handles TextBox1.MouseClick
        TextBox1.SelectionStart = 0

        TextBox1.SelectAll()
    End Sub

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyUp
        If e.KeyCode = Keys.Enter Then
            Dim sP As String = TextBox1.Text
            For i = 0 To ListBox1.Items.Count - 1
                If InStr(ListBox1.Items.Item(i), sP) <> 0 Then
                    ListBox1.SelectedIndex = i
                    Exit Sub
                End If
            Next
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class