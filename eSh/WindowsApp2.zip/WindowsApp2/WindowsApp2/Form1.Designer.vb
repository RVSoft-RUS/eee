﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.theDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.USD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EUR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NEFT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "222"
        '
        'DGV
        '
        Me.DGV.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.theDate, Me.USD, Me.EUR, Me.NEFT})
        Me.DGV.Location = New System.Drawing.Point(13, 33)
        Me.DGV.Name = "DGV"
        Me.DGV.Size = New System.Drawing.Size(538, 352)
        Me.DGV.TabIndex = 2
        '
        'theDate
        '
        Me.theDate.HeaderText = "Дата"
        Me.theDate.Name = "theDate"
        '
        'USD
        '
        Me.USD.HeaderText = "USD"
        Me.USD.Name = "USD"
        '
        'EUR
        '
        Me.EUR.HeaderText = "EUR"
        Me.EUR.Name = "EUR"
        '
        'NEFT
        '
        Me.NEFT.HeaderText = "НЕФТЬ"
        Me.NEFT.Name = "NEFT"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 2000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(563, 397)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.Label1)
        Me.MinimumSize = New System.Drawing.Size(150, 38)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents DGV As DataGridView
    Friend WithEvents theDate As DataGridViewTextBoxColumn
    Friend WithEvents USD As DataGridViewTextBoxColumn
    Friend WithEvents EUR As DataGridViewTextBoxColumn
    Friend WithEvents NEFT As DataGridViewTextBoxColumn
    Friend WithEvents Timer1 As Timer
End Class
