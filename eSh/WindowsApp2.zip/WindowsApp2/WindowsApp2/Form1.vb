﻿Imports System.ComponentModel
Imports System.IO
Imports System.Net
Imports System.Runtime.Serialization

Public Class Form1
    <Serializable> Structure theData
        Dim usd As Single
        Dim eur As Single
        Dim neft As Single
        Dim aDate As Date
    End Structure

    Public allData As New ArrayList
    Private dataFile As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dataFile = Application.StartupPath & "\dataK.xml"
        Dim fStream As FileStream = Nothing
        Try
            fStream = New FileStream(dataFile, FileMode.Open, FileAccess.Read)
            Dim myBinaryFormatter As New Formatters.Binary.BinaryFormatter
            allData = CType(myBinaryFormatter.Deserialize(fStream), ArrayList)
            fStream.Close()
        Catch ex As Exception
            If Not (fStream Is Nothing) Then
                fStream.Close()
            End If
        End Try
        For i = 0 To allData.Count - 1
            Dim curData As theData = allData(i)
            DGV.Rows.Add()
            DGV.Item(0, i).Value = curData.aDate
            DGV.Item(1, i).Value = curData.usd
            DGV.Item(2, i).Value = curData.eur
            DGV.Item(3, i).Value = curData.neft
        Next
        Label1.Text = "Обновление данных ..."
    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim fStream As FileStream = Nothing
        Try
            fStream = New FileStream(dataFile, FileMode.OpenOrCreate, FileAccess.Write)
            Dim myBinaryFormatter As New Formatters.Binary.BinaryFormatter
            myBinaryFormatter.Serialize(fStream, allData)
            fStream.Close()
        Catch ex As Exception
            If Not (fStream Is Nothing) Then
                fStream.Close()
            End If

        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = "Обновление данных ..."
        Application.DoEvents()
        Dim url As String = "https://yandex.ru/"
        Dim page As String
        Try
            Dim pageRequest As HttpWebRequest = CType(WebRequest.Create(url), HttpWebRequest)

            Dim pageResponse As WebResponse = pageRequest.GetResponse
            Dim streamReader As New StreamReader(pageResponse.GetResponseStream)
            page = streamReader.ReadToEnd

            Dim pos As Integer = page.IndexOf("inline-stocks__value_inner") + 28
            Dim usd As String = page.Substring(pos, 5)

            pos = page.IndexOf("inline-stocks__value_inner", pos) + 28
            Dim eur As String = page.Substring(pos, 5)

            pos = page.IndexOf("inline-stocks__value_inner", pos) + 28
            Dim neft As String = page.Substring(pos, 5)


            streamReader.Close()
            Dim nUSD As Single = Single.Parse(usd)
            Dim nEUR As Single = Single.Parse(eur)
            Dim nNEFT As Single = Single.Parse(neft)
            Label1.Text = "USD = " & usd & "      EUR = " & eur & "      НЕФТЬ = " & neft

            Dim snapData, lastData As theData
            snapData.usd = nUSD
            snapData.eur = nEUR
            snapData.neft = nNEFT
            snapData.aDate = Now

            Dim dataLen As Integer = allData.Count
            If dataLen > 0 Then
                lastData = allData(dataLen - 1)
                If Math.Abs(lastData.usd - snapData.usd) > 0.02 Or Math.Abs(lastData.eur - snapData.eur) > 0.02 Or Math.Abs(lastData.neft - snapData.neft) > 0.02 Then
                    allData.Add(snapData)
                    DGV.Rows.Add()
                    DGV.Item(0, dataLen).Value = snapData.aDate
                    DGV.Item(1, dataLen).Value = snapData.usd
                    DGV.Item(2, dataLen).Value = snapData.eur
                    DGV.Item(3, dataLen).Value = snapData.neft
                    DGV.Item(0, dataLen).Selected = True
                End If
            Else
                allData.Add(snapData)
            End If
        Catch ex As Exception

        End Try
        Timer1.Interval = 60000
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        If allData.Count > 1 Then
            graph.Visible = True
        End If
    End Sub
End Class