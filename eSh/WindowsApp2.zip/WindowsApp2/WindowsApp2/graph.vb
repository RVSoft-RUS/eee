﻿Public Class graph
    Dim W, H As Integer 'Размеры полотна для рисования
    Dim dx As Single 'число минут в отрисовываемом интервале
    Dim kx As Single '1 минута = кх делений на рисунке
    Dim t0, tk As Integer
    Dim t1 As Integer

    Dim i As Long = 0

    Private Sub graph_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Dim p As New Pen(Color.Black)
        Dim f As Font = Me.Font
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)

        W = Me.ClientSize.Width
        H = Me.ClientSize.Height - 20
        Dim d, dk As Form1.theData
        Dim d1, d2 As Date
        d = Form1.allData(0)
        d1 = d.aDate
        t1 = d1.Ticks / 600_000_000

        g.DrawString(d1, f, Brushes.Black, New Point(0, H + 5))
        d = Form1.allData(Form1.allData.Count - 1)
        d2 = d.aDate
        g.DrawString(d2, f, Brushes.Black, New Point(W - 100, H + 5))
        dx = (d2.Ticks - d1.Ticks) / 600_000_000
        kx = (W - 20) / dx

        g.DrawLine(p, 20, H, Me.Width, H)
        g.DrawLine(p, 20, 0, 20, H)

        p = New Pen(Color.Green)
        Dim min As Integer = Integer.MaxValue
        Dim max As Integer = Integer.MinValue
        For i = 0 To Form1.allData.Count - 1
            d = Form1.allData(i)
            If min > d.usd Then
                min = CInt(d.usd) - 1
            End If
            If max < d.usd Then
                max = CInt(d.usd) + 1
            End If
        Next
        For i = min To max
            g.DrawString(i, f, Brushes.Green, New Point(0, CInt(H - (i - min) * H / (max - min))))
        Next
        g.DrawString("USD", f, Brushes.Green, New Point(20, 0))

        For i = 0 To Form1.allData.Count - 2
            d = Form1.allData(i)
            t0 = d.aDate.Ticks / 600_000_000 - t1
            dk = Form1.allData(i + 1)
            tk = dk.aDate.Ticks / 600_000_000 - t1
            g.DrawLine(p, CInt(t0 * kx) + 20, CInt(H - (d.usd - min) * H / (max - min)), CInt(tk * kx) + 20, CInt(H - (dk.usd - min) * H / (max - min)))
        Next


        p = New Pen(Color.Blue)
        min = Integer.MaxValue
        max = Integer.MinValue
        For i = 0 To Form1.allData.Count - 1
            d = Form1.allData(i)
            If min > d.eur Then
                min = CInt(d.eur) - 1
            End If
            If max < d.eur Then
                max = CInt(d.eur) + 1
            End If
        Next
        For i = min To max
            g.DrawString(i, f, Brushes.Blue, New Point(W / 2, CInt(H - (i - min) * H / (max - min))))
        Next
        g.DrawString("EUR", f, Brushes.Blue, New Point(W / 2 + 20, 0))
        'Dim t0, tk As Integer
        For i = 0 To Form1.allData.Count - 2
            d = Form1.allData(i)
            t0 = d.aDate.Ticks / 600_000_000 - t1
            dk = Form1.allData(i + 1)
            tk = dk.aDate.Ticks / 600_000_000 - t1
            g.DrawLine(p, CInt(t0 * kx) + 20, CInt(H - (d.eur - min) * H / (max - min)), CInt(tk * kx) + 20, CInt(H - (dk.eur - min) * H / (max - min)))
        Next


        p = New Pen(Color.Red)
        min = Integer.MaxValue
        max = Integer.MinValue
        For i = 0 To Form1.allData.Count - 1
            d = Form1.allData(i)
            If min > d.neft Then
                min = CInt(d.neft) - 1
            End If
            If max < d.neft Then
                max = CInt(d.neft) + 1
            End If
        Next
        For i = min To max
            g.DrawString(i, f, Brushes.Red, New Point(W - 40, CInt(H - (i - min) * H / (max - min))))
        Next
        g.DrawString("NEFT", f, Brushes.Red, New Point(W - 80, 0))
        'Dim t0, tk As Integer
        For i = 0 To Form1.allData.Count - 2
            d = Form1.allData(i)
            t0 = d.aDate.Ticks / 600_000_000 - t1
            dk = Form1.allData(i + 1)
            tk = dk.aDate.Ticks / 600_000_000 - t1
            g.DrawLine(p, CInt(t0 * kx) + 20, CInt(H - (d.neft - min) * H / (max - min)), CInt(tk * kx) + 20, CInt(H - (dk.neft - min) * H / (max - min)))
        Next

    End Sub

    Private Sub graph_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Me.Height += 1
    End Sub

    Private Sub graph_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Dim t As Long
        t = ((e.X - 20) / kx + t1) * 600_000_000
        Dim d As Date = New Date(t)
        ToolTip1.SetToolTip(Me, d)
    End Sub
End Class